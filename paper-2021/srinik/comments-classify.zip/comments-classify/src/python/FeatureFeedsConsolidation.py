#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Consolidating benign-bow, benign-count, malicious-bow and malicious-count feeds and
created a single feed so that it can read as a DataFrame for analysis.

Created on Sun Jul 25 13:25:42 2021

@author: Srrini.K
"""

#importing libraries
import csv

import pandas as pd
import numpy as np


with open('../../data/features/benign-bow.csv', 'r') as f:
    original_benign_bow_data = list(csv.reader(f, delimiter=","))
with open('../../data/features/benign-count.csv', 'r') as f:
    original_benign_count_data = list(csv.reader(f, delimiter=","))
with open('../../data/features/malicious-bow.csv', 'r') as f:
    original_malicious_bow_data = list(csv.reader(f, delimiter=","))
with open('../../data/features/malicious-count.csv', 'r') as f:
    original_malicious_count_data = list(csv.reader(f, delimiter=","))
    
kw_feature_names = np.array(original_benign_bow_data[0:1])
kw_feature_names = kw_feature_names[0]
print(kw_feature_names)
addl_feature_names = np.array(original_benign_count_data[0:1])
addl_feature_names=addl_feature_names[0]
print(addl_feature_names)
feature_names=np.concatenate((kw_feature_names, addl_feature_names, ['benign_mal']), axis=0)
print(feature_names)

benign_bow_data = np.array(original_benign_bow_data[1:], dtype=np.float)
benign_count_data = np.array(original_benign_count_data[1:], dtype=np.float)
benign_data=np.concatenate([benign_bow_data, benign_count_data], axis=1)
benign_target=[0] * benign_data.shape[0]
benign_data=np.hstack((benign_data, np.atleast_2d(benign_target).T))

malicious_bow_data = np.array(original_malicious_bow_data[1:], dtype=np.float)
malicious_count_data = np.array(original_malicious_count_data[1:], dtype=np.float)
malicious_data=np.concatenate([malicious_bow_data, malicious_count_data], axis=1)
malicious_target=[1] * malicious_data.shape[0]
malicious_data=np.hstack((malicious_data, np.atleast_2d(malicious_target).T))

all_comments = np.concatenate((benign_data, malicious_data), axis=0)
##php_kw_dataset = {'data': all_comments, 'feature_names': feature_names}

df = pd.DataFrame(all_comments, columns=feature_names)
df.to_csv ('../../data/features/consolidated.csv', index=False, header=True)

df = pd.DataFrame(feature_names, columns=['feature_names'])
df.to_csv ('../../data/features/feature_names.csv', index=False, header=True)

array = np.array(feature_names)
np.savetxt('../../data/features/feature_names-2.csv', array, fmt="%s", delimiter = ",")