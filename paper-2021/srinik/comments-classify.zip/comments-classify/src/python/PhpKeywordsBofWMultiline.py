#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 24 13:40:53 2020

@author: Srini.K
"""

# import statments
import numpy
import re
import operator
import csv
import os
import sys

from nltk.tokenize import word_tokenize
from time import time 

'''
Tokenize each the sentences, example
Input : "John likes to watch movies. Mary likes movies too"
Ouput : "John","likes","to","watch","movies","Mary","likes","movies","too"
'''
def tokenize(sentences):
    words = []
    for sentence in sentences:
        ##w = word_extraction(sentence)
        w = re.sub("[^\w]", " ",  sentence).split()
        words.extend(w)
       ##words.extend(sentence)
        
    words = sorted(list(set(words)))
    return words

def word_extraction(sentence):
    ignore = ['a', "the", "is"]
    ##words = re.sub("[^\w]", " ",  sentence).split()
    word_tokenize_stime = int(time() * 1000)
    words = word_tokenize(sentence)
    print("-----> word_tokenize time:",  int(time() * 1000) - word_tokenize_stime) 
    cleaned_text = [w.lower() for w in words if w not in ignore]
    return cleaned_text    
    
def generate_bow(vocab, allsentences):    
   ##vocab = tokenize(allsentences)
   ##print("Word List for Document \n{0} \n".format(vocab));
   ##for sentence in allsentences:
   tmp = word_extraction('__TRAIT__')
   ##words = []
   words = word_extraction(allsentences)

   ##'word_extraction()' is not spliting properly some keywords. So the following
   ##logic is to add the words based on the existence.
   donotsplit = ['<?php','=>']
   for w in donotsplit:
       if w in allsentences:
           words.append(w)

   ##print("Words:{0}",words)
   ##bag_vector = numpy.zeros(len(vocab))
   for w in words:
        ##for i,word in enumerate(vocab):
        for v in vocab:
            if v.lower() == w: 
                ##bag_vector[i] += 1 
                vocab[v] += 1
                break
   ##return numpy.array(bag_vector)
   return vocab

   ## print("{0} \n{1}\n".format(sentence,numpy.array(bag_vector)))
##def write_bow_feature(cols, bowDict, csvWriter):
##    for col in cols:
##        csvFp.
    

phpkeywords = numpy.array(['<?php','and','or','xor','__TRAIT__','__FILE__','__DIR__','__NAMESPACE__',
                'exception','__LINE__','array','as','break','case',
               'class','const','continue','declare','default','die','do','echo','else','elseif',
               'empty','enddeclare','endfor','endforeach','endif','endswitch','endwhile','eval','exit','extends',
               'for','foreach','function','global','if','include','include_once','isset','list',
               'new','print','require','require_once','return','static','switch','unset',
               'use','var','while','__FUNCTION__','__CLASS__','__METHOD__','final','php_user_filter',
               'interface','implements','public','private','protected','abstract',
               'clone','try','catch','throw','cfunction','old_function','this','file_put_contents',
               'file_get_contents','assert','__construct','=>','(',')','_POST','_GET', 'base64_decode',
               'insteadof','goto'])
    
countChars = numpy.array(['alpha', 'numbers', 'splchars', 'totalChars'])

##phpvocab = tokenize(phpkeywords)
##print("PHP Word List \n{0} \n".format(phpkeywords)); ##phpvocab));
dictOfWords = { i : 0 for i in phpkeywords }     ##phpvocab }
print("PHP Word Map \n{0} \n".format(dictOfWords));

basePath = '../../data/'
fileInputpath = basePath + 'input/'
fileOutputPath = basePath + 'features/'


##inputfile = filepath + 'post.log'   ##comments-clean.txt' ##'test.txt' ##'post.log' ##singlepost.log
malRben='malicious'   ##'malicious' ##'benign'
featureOutFile = fileOutputPath + malRben + '-bow.csv'   ##'malicious-bow.csv' ##benign-bow.csv##'test.txt' ##'post.log' ##
countFeatureOutFile = fileOutputPath + malRben + '-count.csv'
# Save Numpy array to csv
##numpy.savetxt(featureOutFile, [phpkeywords], delimiter=',', fmt='%s')

content = ''
with open(featureOutFile, "w") as ofp, open(countFeatureOutFile, "w") as cfp:
    feature_writer = csv.writer(ofp, delimiter=',', quotechar='"'
                                , quoting=csv.QUOTE_MINIMAL)
    feature_writer.writerow(phpkeywords)
    
    feature_count_writer = csv.writer(cfp, delimiter=',', quotechar='"'
                                , quoting=csv.QUOTE_MINIMAL)
    feature_count_writer.writerow(countChars)

    directory=fileInputpath + malRben
    for inputfile in os.listdir(directory):
        if inputfile.startswith("."):
            print("Ignoring...[" + inputfile +"]")
            continue
        fullFileName=directory+'/'+inputfile
        print("Processing...[" + inputfile +"]")
        with open(fullFileName, "r") as fp:
            l = fp.readline()
            while l:
  ##              if l != "--------\n" :
  ##                  content = l.strip()
                content = ""
                payload_collection_stime = int(time() * 1000) 
                while l and not l.startswith("--------"):
                    ##print(l)
                    if l.strip():
                        content += l
                        
                    l = fp.readline()
                ##+= l

                if content:
                    payload_collection_etime = int(time() * 1000)
                    print("InputLine: \n", content)
                    print("-----> payload collection time:", payload_collection_etime - payload_collection_stime) 
                    ## reinitializing for each payload/file.
                    dictOfWords = { i : 0 for i in phpkeywords }     ##phpvocab }
                    bag_vector = generate_bow(dictOfWords, content)
                    ##numpy.savetxt(featureOutFile, [bag_vector.values()], delimiter=',', fmt='%s')
                    feature_writer.writerow(bag_vector.values())
                    ##print("{0} \n{1}\n".format(content,numpy.array(bag_vector)))
               ##     print("------\n\n'{0}' \n{1}\n".format(content, sorted(bag_vector.items(),key=operator.itemgetter(1))))
                    bag_vector_etime = int(time() * 1000)
                    print("-----> bag_vector time:", bag_vector_etime - payload_collection_etime) 

                    total_words = len(re.sub("[^\w]", " ",  content).split())
                    
                    word_count_etime = int(time() * 1000)
                    print("-----> total_words time:", word_count_etime - bag_vector_etime) 

               ##     print("Total words:", total_words)
                    
                    ## counts of alphabets, numbers and spl. characters
                    splChars = ''
                    alphaCount = numberCount = splCharCount = 0
                    for i in range(0, len(content)):
                        ch = content[i]
                        
                        if (ch.isalpha()):
                            alphaCount += 1
                        elif (ch.isdigit()):
                            numberCount += 1
                        else:
                            splCharCount += 1
                            splChars += ch
                    
                    totalChars = alphaCount + numberCount + splCharCount
                    feature_count_writer.writerow([alphaCount, numberCount, splCharCount, totalChars]) ;
                    
                    char_count_etime = int(time() * 1000)
                    print("-----> char_count time:", char_count_etime - word_count_etime) 
                    
                print("Next Payload...[" + inputfile +"]")
                l = fp.readline()
                
        print("***** End of File...[" + inputfile +"]")
    print("\n\n\n***** Process Completed....")

                
                
                
                


        ##        sys.exit("done")
          ##      print("Total Characters:", totalChars)
          ##      print("Alphabets:", alphaCount)
          ##      print("Numbers:", numberCount)
          ##      print("Spl.Characters:", splCharCount)

##print("splChars:", splChars)

        

        ##sys.argv[0]
##outfile  = filepath + "feature-bofw.out"

##while True:
  ##  l = raw_input("Prompt:")
  ##  l = input("Prompt:")
##with open(outfile,"w") as file:
##    with open(inputfile) as fp:
##        l = fp.readline()
##        while l:
##            print(l)
##            bag_vector = generate_bow(phpvocab, l)
##            numpy.savetxt(outfile, bag_vector, fmt="%s")
          ##  file.write(l + '\n'.join(map(str, bag_vector)) + '\n\n')
##            l = fp.readline()
